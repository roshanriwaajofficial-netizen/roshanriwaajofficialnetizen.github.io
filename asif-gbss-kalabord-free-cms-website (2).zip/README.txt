ASIF GBSS KALABORD - FREE WEBSITE + EDITOR DASHBOARD

Files:
- index.html: public school website
- .pages.yml: Pages CMS dashboard configuration
- data/site.json: school details and photo gallery
- data/notices.json: notice board entries
- media/: uploaded photos

SETUP:
1. Create a GitHub account (or sign in).
2. Create a NEW PUBLIC repository named exactly: YOUR-USERNAME.github.io
3. Upload ALL files and folders from this ZIP into the repository root. Make sure index.html and .pages.yml are at the top level.
4. In GitHub repository: Settings > Pages > Build and deployment > Source: Deploy from a branch; choose main and /(root), then Save.
5. Wait for GitHub Pages to publish. Your public URL will be https://YOUR-USERNAME.github.io
6. Open https://app.pagescms.org, sign in with GitHub, install/authorize Pages CMS for this repository, and open the repository. It reads .pages.yml.
7. In Pages CMS, edit "School website details" for text and photos; edit "Notice board" to add, change, or delete notices. Save/commit changes.
8. GitHub Pages republishes the committed changes automatically; allow a few minutes.

IMPORTANT:
- Do not share your GitHub password or verification codes with anyone.
- Keep the repository public for free GitHub Pages on GitHub Free. The repository contents are public, so do not put private student information, personal phone numbers, private records, or sensitive data in it.
- The dashboard is a separate service at Pages CMS; its hosted app is free according to its official website. GitHub login is required.
- This starter package does not publish the site automatically: you must complete the GitHub steps above.
